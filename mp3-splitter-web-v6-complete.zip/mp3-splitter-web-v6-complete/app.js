const fileInput = document.querySelector("#fileInput");
const pickButton = document.querySelector("#pickButton");
const dropZone = document.querySelector("#dropZone");
const runButton = document.querySelector("#runButton");
const pauseButton = document.querySelector("#pauseButton");
const stopButton = document.querySelector("#stopButton");
const downloadButton = document.querySelector("#downloadButton");
const fileList = document.querySelector("#fileList");
const statusText = document.querySelector("#statusText");
const sensitivitySelect = document.querySelector("#sensitivity");
const paddingSelect = document.querySelector("#padding");

let files = [];
let latestZipBlob = null;
let jobState = {
  running: false,
  paused: false,
  stopped: false,
  resume: null,
};

const settings = {
  loose: { minSilenceMs: 900, thresholdOffset: -2 },
  normal: { minSilenceMs: 700, thresholdOffset: 0 },
  tight: { minSilenceMs: 460, thresholdOffset: 2 },
};

function setStatus(text) {
  statusText.textContent = text;
}

function updateControlState() {
  runButton.disabled = files.length === 0 || jobState.running;
  pauseButton.disabled = !jobState.running || jobState.stopped;
  stopButton.disabled = !jobState.running || jobState.stopped;
  pauseButton.textContent = jobState.paused ? "继续" : "暂停";
}

function startJobState() {
  jobState = {
    running: true,
    paused: false,
    stopped: false,
    resume: null,
  };
  updateControlState();
}

function finishJobState() {
  if (jobState.resume) jobState.resume();
  jobState = {
    running: false,
    paused: false,
    stopped: false,
    resume: null,
  };
  updateControlState();
}

function stopJobState() {
  jobState.stopped = true;
  jobState.paused = false;
  if (jobState.resume) jobState.resume();
  updateControlState();
}

async function waitIfPaused() {
  while (jobState.paused && !jobState.stopped) {
    await new Promise((resolve) => {
      jobState.resume = resolve;
    });
    jobState.resume = null;
  }
  if (jobState.stopped) {
    throw new Error("用户已停止处理");
  }
}

function renderFiles(rows = []) {
  fileList.innerHTML = "";
  rows.forEach((row) => {
    const card = document.createElement("div");
    card.className = `file-card ${row.active ? "active" : ""}`;
    const progress = Math.max(0, Math.min(100, Math.round(row.progress || 0)));
    card.innerHTML = `
      <div>
        <strong>${escapeHtml(row.name)}</strong>
        <p>${escapeHtml(row.detail)}</p>
        <div class="progress-track" aria-label="${escapeHtml(row.name)} 处理进度">
          <span style="width: ${progress}%"></span>
        </div>
      </div>
      <div class="file-state">
        <span class="percent">${progress}%</span>
        <span class="badge ${row.done ? "" : "pending"}">${escapeHtml(row.badge)}</span>
      </div>
    `;
    fileList.appendChild(card);
  });
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => {
    const map = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
    return map[char];
  });
}

function setFiles(nextFiles) {
  files = [...nextFiles].filter((file) => /\.mp3$/i.test(file.name));
  latestZipBlob = null;
  downloadButton.disabled = true;
  updateControlState();
  if (!files.length) {
    setStatus("还没有可处理的 MP3 文件。");
    renderFiles([]);
    return;
  }
  setStatus(`已选择 ${files.length} 个 MP3，可以开始切分。`);
  renderFiles(
    files.map((file) => ({
      name: file.name,
      detail: formatBytes(file.size),
      badge: "待处理",
      done: false,
      active: false,
      progress: 0,
    })),
  );
}

function formatBytes(bytes) {
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

function percentile(values, pct) {
  if (!values.length) return -60;
  const sorted = [...values].sort((a, b) => a - b);
  const pos = ((sorted.length - 1) * pct) / 100;
  const lo = Math.floor(pos);
  const hi = Math.ceil(pos);
  if (lo === hi) return sorted[lo];
  return sorted[lo] * (hi - pos) + sorted[hi] * (pos - lo);
}

function makeMono(buffer) {
  const channelCount = buffer.numberOfChannels;
  const length = buffer.length;
  const mono = new Float32Array(length);
  for (let channel = 0; channel < channelCount; channel += 1) {
    const data = buffer.getChannelData(channel);
    for (let i = 0; i < length; i += 1) {
      mono[i] += data[i] / channelCount;
    }
  }
  return mono;
}

function rmsDb(samples, start, end) {
  let sum = 0;
  const count = Math.max(1, end - start);
  for (let i = start; i < end; i += 1) {
    const v = samples[i] || 0;
    sum += v * v;
  }
  const rms = Math.sqrt(sum / count);
  return 20 * Math.log10(Math.max(rms, 0.000001));
}

function dbCurve(samples, sampleRate, windowMs = 20) {
  const windowSize = Math.max(1, Math.round((sampleRate * windowMs) / 1000));
  const curve = [];
  for (let start = 0; start < samples.length; start += windowSize) {
    curve.push(rmsDb(samples, start, Math.min(samples.length, start + windowSize)));
  }
  return { curve, windowSize };
}

function findSilentRuns(curve, windowSize, sampleRate, threshold, minSilenceMs) {
  const windowMs = (windowSize * 1000) / sampleRate;
  const minWindows = Math.max(1, Math.round(minSilenceMs / windowMs));
  const runs = [];
  let start = null;
  curve.forEach((db, index) => {
    if (db <= threshold) {
      if (start === null) start = index;
    } else if (start !== null) {
      if (index - start >= minWindows) runs.push([start * windowSize, index * windowSize]);
      start = null;
    }
  });
  if (start !== null && curve.length - start >= minWindows) {
    runs.push([start * windowSize, curve.length * windowSize]);
  }
  return runs;
}

function buildSegments(silentRuns, totalSamples, sampleRate, padMs) {
  const minSegment = Math.round(sampleRate * 0.9);
  const pad = Math.round((sampleRate * padMs) / 1000);
  const segments = [];
  let cursor = 0;
  silentRuns.forEach(([silStart, silEnd]) => {
    const boundary = Math.round((silStart + silEnd) / 2);
    if (boundary - cursor >= minSegment) {
      segments.push([Math.max(0, cursor - pad), Math.min(totalSamples, boundary + pad)]);
      cursor = boundary;
    }
  });
  if (totalSamples - cursor >= minSegment) {
    segments.push([Math.max(0, cursor - pad), totalSamples]);
  }
  return segments.length ? segments : [[0, totalSamples]];
}

function detectSegments(samples, sampleRate, mode, padMs) {
  const { curve, windowSize } = dbCurve(samples, sampleRate);
  const noise = percentile(curve, 20);
  const speech = percentile(curve, 85);
  const chosen = settings[mode];
  const threshold = Math.min(-32, Math.max(noise + 8, speech - 26)) + chosen.thresholdOffset;
  const silentRuns = findSilentRuns(
    curve,
    windowSize,
    sampleRate,
    threshold,
    chosen.minSilenceMs,
  );
  return buildSegments(silentRuns, samples.length, sampleRate, padMs);
}

function floatToInt16(samples, start, end) {
  const output = new Int16Array(end - start);
  for (let i = start; i < end; i += 1) {
    const value = Math.max(-1, Math.min(1, samples[i] || 0));
    output[i - start] = value < 0 ? value * 32768 : value * 32767;
  }
  return output;
}

function encodeMp3(samples, sampleRate, start, end) {
  const encoder = new lamejs.Mp3Encoder(1, sampleRate, 128);
  const pcm = floatToInt16(samples, start, end);
  const chunks = [];
  const blockSize = 1152;
  for (let i = 0; i < pcm.length; i += blockSize) {
    const encoded = encoder.encodeBuffer(pcm.subarray(i, i + blockSize));
    if (encoded.length) chunks.push(encoded);
  }
  const finalChunk = encoder.flush();
  if (finalChunk.length) chunks.push(finalChunk);
  return new Blob(chunks, { type: "audio/mpeg" });
}

async function decodeFile(file) {
  const audioContext = new (window.AudioContext || window.webkitAudioContext)();
  const data = await file.arrayBuffer();
  try {
    return await audioContext.decodeAudioData(data.slice(0));
  } finally {
    await audioContext.close();
  }
}

async function processFile(file, zip, mode, padMs, onProgress) {
  await waitIfPaused();
  onProgress(8, "读取音频");
  const buffer = await decodeFile(file);
  await waitIfPaused();
  onProgress(25, "分析声道");
  const mono = makeMono(buffer);
  await waitIfPaused();
  onProgress(34, "识别停顿");
  const segments = detectSegments(mono, buffer.sampleRate, mode, padMs);
  const base = file.name.replace(/\.mp3$/i, "");
  const folder = zip.folder(`${base}_sentences`);
  const manifest = [["file", "start_seconds", "end_seconds", "duration_seconds"]];
  for (let index = 0; index < segments.length; index += 1) {
    await waitIfPaused();
    const [start, end] = segments[index];
    const mp3 = encodeMp3(mono, buffer.sampleRate, start, end);
    const name = `${String(index + 1).padStart(3, "0")}.mp3`;
    folder.file(name, mp3);
    manifest.push([
      name,
      (start / buffer.sampleRate).toFixed(3),
      (end / buffer.sampleRate).toFixed(3),
      ((end - start) / buffer.sampleRate).toFixed(3),
    ]);
    const encodedRatio = (index + 1) / segments.length;
    onProgress(35 + encodedRatio * 55, `编码第 ${index + 1}/${segments.length} 段`);
    await new Promise((resolve) => setTimeout(resolve, 0));
  }
  await waitIfPaused();
  folder.file("segments.csv", manifest.map((row) => row.join(",")).join("\n"));
  onProgress(96, "写入压缩包");
  return segments.length;
}

async function runSplit() {
  if (!window.JSZip || !window.lamejs) {
    setStatus("页面依赖还没加载完成，请刷新后重试。");
    return;
  }
  startJobState();
  downloadButton.disabled = true;
  latestZipBlob = null;
  const zip = new JSZip();
  const mode = sensitivitySelect.value;
  const padMs = Number(paddingSelect.value);
  const rows = files.map((file) => ({
    name: file.name,
    detail: formatBytes(file.size),
    badge: "处理中",
    done: false,
    active: false,
    progress: 0,
  }));
  renderFiles(rows);

  try {
    let totalSegments = 0;
    for (let i = 0; i < files.length; i += 1) {
      await waitIfPaused();
      setStatus(`正在处理 ${i + 1}/${files.length}：${files[i].name}`);
      rows.forEach((row, rowIndex) => {
        row.active = rowIndex === i;
        if (rowIndex > i) row.progress = 0;
      });
      renderFiles(rows);
      const count = await processFile(files[i], zip, mode, padMs, (progress, detail) => {
        rows[i] = {
          ...rows[i],
          detail,
          badge: "处理中",
          active: true,
          progress,
        };
        renderFiles(rows);
      });
      totalSegments += count;
      rows[i] = {
        name: files[i].name,
        detail: `已切成 ${count} 段`,
        badge: "完成",
        done: true,
        active: false,
        progress: 100,
      };
      renderFiles(rows);
      await new Promise((resolve) => setTimeout(resolve, 20));
    }
    await waitIfPaused();
    setStatus(`正在生成下载包：${files.length} 个文件，共 ${totalSegments} 段。`);
    latestZipBlob = await zip.generateAsync(
      { type: "blob" },
      (metadata) => {
        if (jobState.stopped) return;
        setStatus(`正在生成下载包：${Math.round(metadata.percent)}%`);
      },
    );
    await waitIfPaused();
    setStatus(`完成：${files.length} 个文件，共 ${totalSegments} 段。`);
    downloadButton.disabled = false;
  } catch (error) {
    console.error(error);
    latestZipBlob = null;
    downloadButton.disabled = true;
    setStatus(jobState.stopped ? "已停止。本次结果没有生成，可以重新选择文件后再开始。" : `处理失败：${error.message || "请换一个 MP3 试试"}`);
    rows.forEach((row) => {
      if (!row.done) row.badge = "未完成";
      row.active = false;
    });
    renderFiles(rows);
  } finally {
    finishJobState();
  }
}

pickButton.addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", () => setFiles(fileInput.files));
runButton.addEventListener("click", runSplit);
pauseButton.addEventListener("click", () => {
  if (!jobState.running) return;
  jobState.paused = !jobState.paused;
  if (!jobState.paused && jobState.resume) jobState.resume();
  setStatus(jobState.paused ? "已暂停，点击“继续”会接着处理。" : "继续处理中。");
  updateControlState();
});
stopButton.addEventListener("click", () => {
  if (!jobState.running) return;
  stopJobState();
  setStatus("正在停止，请稍等当前小步结束。");
});
downloadButton.addEventListener("click", () => {
  if (!latestZipBlob) return;
  const url = URL.createObjectURL(latestZipBlob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = "mp3-sentences.zip";
  anchor.click();
  URL.revokeObjectURL(url);
});

["dragenter", "dragover"].forEach((eventName) => {
  dropZone.addEventListener(eventName, (event) => {
    event.preventDefault();
    dropZone.classList.add("dragging");
  });
});

["dragleave", "drop"].forEach((eventName) => {
  dropZone.addEventListener(eventName, (event) => {
    event.preventDefault();
    dropZone.classList.remove("dragging");
  });
});

dropZone.addEventListener("drop", (event) => {
  setFiles(event.dataTransfer.files);
});
